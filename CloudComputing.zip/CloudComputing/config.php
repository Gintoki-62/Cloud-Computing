<?php
$host = "gradstore.cgy7bkymusom.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "ilovegroot"; 
$database = "clouddb";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Connection Error:" . mysqli_connect_error());
}
?>
